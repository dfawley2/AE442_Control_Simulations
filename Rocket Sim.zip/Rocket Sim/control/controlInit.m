function ctrl = controlInit(controller)

ctrl.igniteMotor = 0;
ctrl.tIgnite = 1;

end