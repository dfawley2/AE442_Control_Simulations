% Add appropriate paths for sim
addpath('control');
addpath('data');
addpath('get');
addpath('motor');
addpath('navigation');
addpath('utilities');

