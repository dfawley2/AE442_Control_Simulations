function nav = navInit(models)


nav = [];

end